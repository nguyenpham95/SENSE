﻿var myApp = angular.module("myApp", ['ngResource']);
myApp.controller("mainCrl", function ($scope,$http) {
    $scope.projectNum = 1;
    $scope.announceNum = 3;
    $http.get("WebService.asmx/getAnnouncement").then(function (response) {
        $scope.announces = response.data;
    });
    $http.get("WebService.asmx/getNoti").then(function (response) {
        $scope.notis = [];
        var i = 0;
        while (i <= 3) {
            $scope.notis[i] = response.data[i];
            i = i + 1;
        }
    });
});